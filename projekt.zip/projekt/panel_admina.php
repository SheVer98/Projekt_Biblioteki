<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <![endif]-->
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Admin Dashboard</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!-- <link rel="stylesheet" href="style.css"> -->
</head>
<style>
    .innerright,
    label {
        color: rgb(0, 0, 0);
        font-weight: bold;
    }

    .container,
    .row,
    .imglogo {
        margin: auto;
    }

    .innerdiv {
        text-align: center;
        /* width: 500px; */
        margin: 10px;
    }

    input {
        margin-left: 20px;
    }

    .leftinnerdiv {
        float: left;
        width: 25%;
    }

    .rightinnerdiv {
        float: right;
        width: 75%;
    }

    .innerright {
        background-color: rgb(37, 212, 232);
    }

    .bluebtn {
        background-color: rgb(53, 112, 232);
        color: white;
        width: 95%;
        height: 40px;
        margin-top: 8px;
    }

    .bluebtn,
    a {
        text-decoration: none;
        color: white;
        font-size: large;
    }

    th {
        background-color: rgb(185, 198, 139);
        color: black;
    }

    td {
        background-color: rgb(215, 207, 163);
        color: black;
    }

    td,
    a {
        color: black;
    }
</style>

<body>

    <?php
    include("data_class.php");

    $msg = "";

    if (!empty($_REQUEST['msg'])) {
        $msg = $_REQUEST['msg'];
    }

    if ($msg == "done") {
        echo "<div class='alert alert-success' role='alert'>Sucssefully Done</div>";
    } elseif ($msg == "fail") {
        echo "<div class='alert alert-danger' role='alert'>Fail</div>";
    }

    ?>



    <div class="container">
        <div class="innerdiv">
            <div class="row"><img class="imglogo" src="images/logo1.png" /></div>
            <div class="leftinnerdiv">
                <Button class="bluebtn" onclick="openpart('addbook1')">Dodaj ksiazke</Button>
                <Button class="bluebtn" onclick="openpart('bookreport')"> Lista ksiazek</Button>
                <Button class="bluebtn" onclick="openpart('bookrequestapprove')"> Prosby o wypozyczenie</Button>
                <Button class="bluebtn" onclick="openpart('addperson')"> Dodaj uzytkownika</Button>
                <Button class="bluebtn" onclick="openpart('studentrecord')"> Lista uzytkownikow</Button>
                <Button class="bluebtn" onclick="openpart('issuebook')"> Wydaj ksiazke</Button>
                <Button class="bluebtn" onclick="openpart('issuebookreport')"> Wydane ksiazki</Button>
                <a href="main.php"><Button class="bluebtn"> Wyloguj</Button></a>
            </div>

            <div class="rightinnerdiv">
                <div id="bookrequestapprove" class="innerright portion" style="display:none">
                    <Button class="bluebtn">Zatwierdzenie prosby o ksiazke</Button>

                    <?php
                    $u = new data;
                    $u->setconnection();
                    $u->requestbookdata();
                    $recordset = $u->requestbookdata();

                    $table = "<table style='font-family: Arial, Helvetica, sans-serif;border-collapse: collapse;width: 100%;'><tr><th style='  border: 1px solid #ddd;
            padding: 8px;'>Nazwisko</th><th>Typ uzytkownika</th><th>Tytul ksiazki</th><th>Dni </th><th>Zatwierdzenie</th></tr>";
                    foreach ($recordset as $row) {
                        $table .= "<tr>";
                        "<td>$row[0]</td>";
                        "<td>$row[1]</td>";
                        "<td>$row[2]</td>";

                        $table .= "<td>$row[3]</td>";
                        $table .= "<td>$row[4]</td>";
                        $table .= "<td>$row[5]</td>";
                        $table .= "<td>$row[6]</td>";
                         $table.="<td><a href='prosba_o_zatwierdzenie.php?reqid=$row[0]&book=$row[5]&userselect=$row[3]&days=$row[6]'><button type='button' class='btn btn-primary'>Zatwierdz</button></a></td>";
                        $table .= "</tr>";
                    }
                    $table .= "</table>";

                    echo $table;
                    ?>

                </div>
            </div>

            <div class="rightinnerdiv">
                <div id="addbook1" class="innerright portion" style="<?php if (!empty($_REQUEST['viewid'])) {
                                                                        echo "display:none";
                                                                    } else {
                                                                        echo "";
                                                                    } ?>">
                    <Button class="bluebtn">Dodaj ksiazke</Button>
                    <form action="dodaj_ksiazke.php" method="post" enctype="multipart/form-data">
                        <label>Tytul ksiazki:</label><input type="text" name="bookname" />
                        </br>
                        <label>Opis:</label><input type="text" name="bookdetail" /></br>
                        <label>Autor:</label><input type="text" name="bookauthor" /></br>
                        <label>Gatunek:</label><input type="text" name="branch" /></br>
                        <label>Cena:</label><input type="text" name="bookprice" /></br>
                        <label>Ilosc:</label><input type="text" name="bookava" /></br>
                        </br>
                        <input type="submit" value="Zatwierdz" />
                        </br>
                        </br>

                    </form>
                </div>
            </div>


            <div class="rightinnerdiv">
                <div id="addperson" class="innerright portion" style="display:none">
                    <Button class="bluebtn">Dodaj uzytkownika</Button>
                    <form action="dodaj_uzytkownika.php" method="post" enctype="multipart/form-data">
                        <label>Nazwisko:</label><input type="text" name="addname" />
                        </br>
                        <label>Haslo:</label><input type="pasword" name="addpass" />
                        </br>
                        <label>Email:</label><input type="email" name="addemail" /></br>
                        <label for="typw">Wybierz typ:</label>
                        <select name="type">
                            <option value="student">student</option>
                            <option value="nauczyciel">nauczyciel</option>
                        </select>

                        <input type="submit" value="Zatwierdz" />
                    </form>
                </div>
            </div>

            <div class="rightinnerdiv">
                <div id="studentrecord" class="innerright portion" style="display:none">
                    <Button class="bluebtn">Lista uzytkownikow</Button>

                    <?php
                    $u = new data;
                    $u->setconnection();
                    $u->userdata();
                    $recordset = $u->userdata();

                    $table = "<table style='font-family: Arial, Helvetica, sans-serif;border-collapse: collapse;width: 100%;'><tr><th style='  border: 1px solid #ddd;
            padding: 8px;'> Nazwisko</th><th>Email</th><th>Typ uzytkownika</th></tr>";
                    foreach ($recordset as $row) {
                        $table .= "<tr>";
                        "<td>$row[0]</td>";
                        $table .= "<td>$row[1]</td>";
                        $table .= "<td>$row[2]</td>";
                        $table .= "<td>$row[4]</td>";
                        //$table.="<td><a href='usun_uzytkownika.php?useriddelete=$row[0]'>Delete</a></td>";
                        $table .= "</tr>";
                    }
                    $table .= "</table>";

                    echo $table;
                    ?>

                </div>
            </div>

            <div class="rightinnerdiv">
                <div id="issuebookreport" class="innerright portion" style="display:none">
                    <Button class="bluebtn">Udostepnione ksiazki</Button>

                    <?php
                    $u = new data;
                    $u->setconnection();
                    $u->issuereport();
                    $recordset = $u->issuereport();

                    $table = "<table style='font-family: Arial, Helvetica, sans-serif;border-collapse: collapse;width: 100%;'><tr><th style='  border: 1px solid #ddd;
            padding: 8px;'>Nazwisko</th><th>Tytul ksiazki</th><th>Data wydania</th><th>Wydano do</th></th><th>Typ uzytkownika</th></tr>";

                    foreach ($recordset as $row) {
                        $table .= "<tr>";
                        "<td>$row[0]</td>";
                        $table .= "<td>$row[2]</td>";
                        $table .= "<td>$row[3]</td>";
                        $table .= "<td>$row[6]</td>";
                        $table .= "<td>$row[7]</td>";
                        $table .= "<td>$row[4]</td>";
                        $table .= "</tr>";
                    }
                    $table .= "</table>";

                    echo $table;
                    ?>

                </div>
            </div>

            <!--             

issue book -->
            <div class="rightinnerdiv">
                <div id="issuebook" class="innerright portion" style="display:none">
                    <Button class="bluebtn">Wydaj ksiazke</Button>
                    <form action="wydane_ksiazki.php" method="post" enctype="multipart/form-data">
                        <label for="book">Wydaj ksiazke:</label>
                        <select name="book">
                            <?php
                            $u = new data;
                            $u->setconnection();
                            $u->getbookissue();
                            $recordset = $u->getbookissue();
                            foreach ($recordset as $row) {

                                echo "<option value='" . $row[2] . "'>" . $row[2] . "</option>";
                            }
                            ?>
                        </select>

                        <label for="Select Student">:</label>
                        <select name="userselect">
                            <?php
                            $u = new data;
                            $u->setconnection();
                            $u->userdata();
                            $recordset = $u->userdata();
                            foreach ($recordset as $row) {
                                $id = $row[0];
                                echo "<option value='" . $row[1] . "'>" . $row[1] . "</option>";
                            }
                            ?>
                        </select>
                        <br>
                        Dni<input type="number" name="days" />

                        <input type="submit" value="Zatwierdz" />
                    </form>
                </div>
            </div>

            <div class="rightinnerdiv">
                <div id="bookdetail" class="innerright portion" style="<?php if (!empty($_REQUEST['viewid'])) {
                                                                            $viewid = $_REQUEST['viewid'];
                                                                        } else {
                                                                            echo "display:none";
                                                                        } ?>">

                    <Button class="bluebtn">Dane ksiazki</Button>
                    </br>
                    <?php
                    $u = new data;
                    $u->setconnection();
                    $u->getbookdetail($viewid);
                    $recordset = $u->getbookdetail($viewid);
                    foreach ($recordset as $row) {

                        $bookid = $row[0];
                        $bookname = $row[2];
                        $bookdetail = $row[3];
                        $bookauthor = $row[1];
                        $branch = $row[4];
                        $bookprice = $row[5];
                        $bookquantity = $row[6];
                    }
                    ?>
                    <p style="color:black"><u>Tytul ksiazki:</u> &nbsp&nbsp<?php echo $bookname ?></p>
                    <p style="color:black"><u>Opis ksiazki:</u> &nbsp&nbsp<?php echo $bookdetail ?></p>
                    <p style="color:black"><u>Autor ksiazki:</u> &nbsp&nbsp<?php echo $bookauthor ?></p>
                    <p style="color:black"><u>Gatunek ksiazki:</u> &nbsp&nbsp<?php echo $branch ?></p>
                    <p style="color:black"><u>Cena ksiazki:</u> &nbsp&nbsp<?php echo $bookprice ?></p>



                </div>
            </div>



            <div class="rightinnerdiv">
                <div id="bookreport" class="innerright portion" style="display:none">
                    <Button class="bluebtn">Lista ksiazek</Button>
                    <?php
                    $u = new data;
                    $u->setconnection();
                    $u->getbook();
                    $recordset = $u->getbook();

                    $table = "<table style='font-family: Arial, Helvetica, sans-serif;border-collapse: collapse;width: 100%;'><tr><th style='  border: 1px solid #ddd;
            padding: 8px;'>Tytul ksiazki</th><th>Cena</th><th>Ilosc</th></th><th>Dodatkowe dane</th></tr>";
                    foreach ($recordset as $row) {
                        $table .= "<tr>";
                        "<td>$row[0]</td>";
                        $table .= "<td>$row[2]</td>";
                        $table .= "<td>$row[5]</td>";
                        $table .= "<td>$row[7]</td>";
                        $table .= "<td><a href='panel_admina.php?viewid=$row[0]'><button type='button' class='btn btn-primary'>Opis</button></a></td>";
                        $table .= "</tr>";
                    }
                    $table .= "</table>";

                    echo $table;
                    ?>

                </div>
            </div>



        </div>
    </div>



    <script>
        function openpart(portion) {
            var i;
            var x = document.getElementsByClassName("portion");
            for (i = 0; i < x.length; i++) {
                x[i].style.display = "none";
            }
            document.getElementById(portion).style.display = "block";
        }
    </script>
</body>

</html>