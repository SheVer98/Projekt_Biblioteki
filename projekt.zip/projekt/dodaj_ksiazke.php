<?php
include("data_class.php");


$bookname=$_POST['bookname'];
$bookauthor=$_POST['bookauthor'];
$bookdetail=$_POST['bookdetail'];
$branch=$_POST['branch'];
$bookprice=$_POST['bookprice'];
$bookquantity=$_POST['bookquantity'];
$bookava=$_POST['bookava'];
$bookrent=$_POST['bookrent'];


$obj=new data();
$obj->setconnection();
$obj->addbook($bookname,$bookauthor, $bookdetail,$branch,$bookprice,$bookquantity, $bookava, $bookrent);

 